# @cortexcloud/mcp

MCP (Model Context Protocol) server for **CortexCloud** — an agent-native AI & on-chain
data gateway. Agents pay per call in **USDC on Base via x402** — no API keys, no signup,
no subscriptions. Payment *is* authentication.

## Install

```bash
npm install -g @cortexcloud/mcp
# or run directly:
npx @cortexcloud/mcp
```

## Configure (Claude Code / Codex / any MCP client)

```bash
claude mcp add cortexcloud -s user -- npx @cortexcloud/mcp
```

Set your agent wallet (pays for x402 calls):

```bash
export CORTEXCLOUD_PRIVATE_KEY=0xYOUR_BASE_WALLET_PRIVATE_KEY   # funds in USDC on Base
export CORTEXCLOUD_BASE_URL=https://api.cortexcloud.org           # optional, this is the default
```

> The wallet needs USDC on Base (`eip155:8453`). No ETH required — x402 uses gasless
> EIP-3009 authorization. The merchant (CortexCloud) settles on-chain.

## Tools

| Tool | Paid? | Description |
|------|-------|-------------|
| `cortexcloud_models` | free | List all available models |
| `cortexcloud_chat` | ✅ USDC | OpenAI-compatible chat completion |
| `cortexcloud_base_balance` | ✅ USDC | Native ETH balance of a Base address |
| `cortexcloud_base_token_balance` | ✅ USDC | ERC-20 token balance on Base |
| `cortexcloud_prices` | ✅ USDC | Crypto prices (CoinGecko) |
| `cortexcloud_dex_search` | ✅ USDC | DEX pair search (DEXScreener) |

## Example (Claude Code)

```
> Use cortexcloud_chat with model "groq/llama-3.3-70b-versatile" to summarize this doc.
```

The agent signs an x402 payment, the call settles in USDC, the receipt is on-chain.

## Local development

```bash
npm install
npm run build
CORTEXCLOUD_PRIVATE_KEY=0x... npm run dev
```

## License

MIT
